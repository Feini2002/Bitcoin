# 收集生命周期与最小契约

本节字段是拟议设计，应映射原卷10及真实schema；不要求建立平行数据库。本目录JSON Schema仅校验补充对象，不替代完整业务校验。

## 1. 对象映射

| 补充对象 | 字段责任 | 与原方案关系 |
|---|---|---|
| SourceCandidate | 发现入口、用途问题、核验状态、未确认事项 | 研究资料库提名，不是已批准SourcePolicy |
| SourceRegistration | 运行端点、身份、用途、限额、调度和owner | 扩展/复用原SourcePolicy及来源配置 |
| CollectionAttempt | 请求窗口、游标、HTTP/解析状态、失败、预算与计数 | 可映射原run/step或采集日志，不混同报告run |
| ResourceVersion | 响应/内容身份、取得时间、发布时间精度、提取版本、权利 | 映射原ArticleVersion/Artifact，不另造事实真值 |
| ClaimCandidate | 极性、模态、数值、定位、状态和缺失 | 映射原主张对象；不是自动confirmed |
| CoverageReport | 必需来源健康、事件范围、已知缺口、允许静默结论 | 给原bundle/data_limitations使用 |

## 2. 状态与转移

候选来源：discovered→examined→pilot_eligible→active；任意状态可paused/rejected，需原因。授权unknown不自动使全部系统失败，只限制该用途。

采集尝试：queued→fetching→received→validated→persisted→indexed；终态可unchanged、partial、failed、denied、cancelled。`received`不等于内容有效，`indexed`不等于事实正确。索引失败不能回退游标导致重复写入，应支持幂等重建。

文档版本：metadata_only/parsed/partial→superseded或retracted；rights_restricted独立于内容真伪。删除操作按政策影响原文、摘要、嵌入、缓存和导出；保留合法tombstone表明旧引用为什么无法恢复。

主张：extracted→reviewed/unsupported/conflicted；支持关系只能指向允许且实际读取的定位。模型不得通过改status自授确认。

## 3. 时间

source_published_at可空且带精度；first_seen_at是本系统第一次发现；fetched_at是真实取得时间；ingested_at是写入；source_updated_at和版本关系表示更正。不能把一者缺失用另一者填上而不记录推断。

历史system-observed查询要求实际first_seen/fetched<=cutoff；public-available重建需可信发布时间和版本；retrospective-latest可以用最终版本但必须明示。发布时间未知时可以作为当前材料，不能进入精确历史可用性结论。

## 4. 幂等与内容身份

资源键采用source＋来源对象ID/规范URL＋版本或规范内容摘要，仍保留原URL。URL规范化只删除已确认跟踪参数，不能任意删查询参数改变页面语义。正文hash与提取版本绑定；源改正文但发布时间未变时仍产生新版本。

采集attempt_id与resource_version_id不同：多次抓到同一版本只增加尝试日志，不重复文章；同URL新版本必须保留。队列至少一次投递条件下，persist和索引都有幂等键。

## 5. 拟议API职责

以下仅建议，不声称仓库已有这些路由。实际命名绑定后更新原OpenAPI，而不是运行两个同义API。

|操作|方法/示例路径|语义|
|---|---|---|
|发现候选|POST /research/source-candidates|写入候选，不启用网络|
|查询目录|GET /research/source-candidates|按主题、证据状态、用途过滤|
|登记来源|POST /research/sources|校验运行端点、owner、用途与预算|
|触发有限采集|POST /research/collection-runs|幂等请求，明确范围与上限|
|查看采集|GET /research/collection-runs/{id}|失败/覆盖/费用与产物引用|
|查看文档版本|GET /research/resources/{id}/versions|严格用途过滤，不无条件返回全文|
|证据查询|POST /research/evidence/search|query、cutoff、purpose、language、source_scope|
|建议关系|POST /research/claims/relations|候选合并/更正，非永久删记录|
|撤回或更正|POST /research/resources/{id}/status-events|append事件，不篡改原历史|
|覆盖检查|GET /research/coverage|必需源、时间窗、缺口、静默结论资格|

写接口需要现有认证/防CSRF等策略；公开网站不把管理员登记与采集触发暴露成匿名接口。模型工具使用source_id/resource_key，不直接调用任意URL接口。

## 6. 缓存和导出

查询缓存含用户/用途、policy版本、cutoff、索引/方法版本和筛选。数据撤回或权限变化要失效，不能只按query缓存。导出携带来源、版本、时间模式与质量；受限内容不因下载Markdown而绕过展示规则。

## 7. 事务边界

先落资源与manifest，再推进游标；索引是可重建投影。报告读取封存bundle，不读未完成采集事务。批次部分成功时保存每源状态，允许有限结果但不假装整批完整。具体数据库事务能力要在真实部署核验，不能用一个“atomic”字段假称跨API原子。
