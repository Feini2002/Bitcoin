# TOOL066｜Unstructured

查询日期：2026-09-16。已核验事实仅限下列直接材料；实验未执行。

## 身份与直接证据

类型：文档元素化与摄取框架。

官方库将不同文档处理成结构化元素，企业平台与托管接口具有独立边界。开源分区器不等于全部商业处理能力。

[EXT146｜Unstructured 开源库](https://github.com/Unstructured-IO/unstructured) [EXT147｜Unstructured 库许可证](https://raw.githubusercontent.com/Unstructured-IO/unstructured/main/LICENSE.md)

## 可以吸收的具体成果

在异构文档多时统一title/text/table等元素，保留原文定位和metadata，再用于检索或主张抽取。流水线阶段可独立测量失败。

## 不适用与负面证据

元素分类正确不代表阅读顺序与数值关系正确。分块过早会把单位表头与数字分离；单一chunk-size不能适用所有文档。

## 代码、数据与服务权利

主库Apache-2.0已核；模型、云API、连接器与原始内容许可另审。

## 运行与成本边界

Python及文件格式/解析依赖，托管服务可减少环境维护但有外发/费用；不是所有能力本地和云端等价。

## 维护证据及其限度

项目当前文档可核，未执行各partition策略或最新平台功能。

## 竞争替代与选型条件

Docling侧重统一文档结构，GROBID侧重论文，静态HTML用Readability更轻。选择一种主提取路径并保留明确回退。

## 最低成本核验实验

比较同文档在元素化、分块、检索后是否保留关键否定/数值单位；没有原始定位就不进入引用报告。

## 两轴判断

**一般适用性：**异构材料平台候选。

**当前仓库适用性：**按真实文档类型和维护负担选择，不因已有connector列表就全量引入。
