# RES08｜订单流足迹与盘口研究

研究日期：2026-09-16。本卷是独立基础研究，不要求匹配当前仓库；“建议/迁移启示”是本研究的推论，不是项目官方承诺。未运行候选代码。


## 1. 三种买卖力量不是同一个指标

成交delta/CVD来自被分类的主动成交；盘口不平衡来自可见挂单；订单流不平衡OFI可按具体方法结合最优价位事件变化。它们观察不同现象，不能仅因名字含flow就合成三票确认。

Cont等论文讨论订单簿事件与价格变化，研究范围是其特定市场样本，不能直接当BTC已验证规律。迁移价值是明确可检验定义，而不是照搬系数或结论。[EXT089｜Cont等：订单簿事件价格影响](https://arxiv.org/html/1011.6402v3)

## 2. 足迹的最小定义

明确基础粒度、时间窗口、价格桶宽/锚点、主动方向规则、数量单位和未完成桶。真实成交与估算分类分别命名。对跨周期重聚合，先验证同一覆盖范围的数量守恒；不能先画出漂亮格子，再解释每个格子都有真实订单支持。

POC、价值区和失衡的算法也需要版本：同价并列怎样处理、价值区扩展顺序、最小成交过滤及零分母规则都会影响结果。没有成交不能补成零卖量来制造无限买卖比；缺失与真实零分别处理。

## 3. 盘口复建与解释边界

按交易所协议建立快照/增量序列，合法删除档位、断档重建、明确深度与采样。可见深度受接口限制，并不是全部市场流动性。挂单撤销可能影响显示的压力，但不等于实际成交或意图已知。[EXT123｜Binance Spot WebSocket 原始规范](https://raw.githubusercontent.com/binance/binance-spot-api-docs/master/web-socket-streams.md)

热力图适合帮助定位挂单和成交变化，但不宜直接标“庄家吸筹”或“必然支撑”。应显示观察事实与候选解释，要求后续成交或价格响应作为检验。对撤单/欺骗意图不能仅凭一帧图断言。

## 4. 成熟框架的边界

HftBacktest研究队列和执行假设，Nautilus提供更通用事件驱动过程。它们适合精细回放/仿真，代价是更高粒度数据和更多模型假设。当前仅解释市场条件的产品可以借鉴事件和时间模型，不必接账户和订单执行。[EXT055｜HftBacktest 官方仓库](https://github.com/nkaz001/hftbacktest) [EXT054｜NautilusTrader 官方仓库](https://github.com/nautechsystems/nautilus_trader)

## 5. 衡量是否增加独立信息

把价格变化作为基线，逐项加入CVD、盘口、OI、可见清算，观察对预声明问题的解释/预测增量。不能只看同一窗口里哪些指标与价格共同变化。若目标是解释，就记录多少重要反例被显露；若目标是预测，则有未来标签、可用时点和样本外评价。

保留“成交与盘口矛盾”的结果，而不是强制多数投票合成一个方向。分歧可能来自市场差异、采样不齐或真实行为，也可能只是数据错误；先排除质量问题，再提出金融解释。新增指标没有让用户更清楚哪些条件成立时，应考虑退役而不是不断调整权重。


## 证据与进一步核验

[EXT089｜Cont等：订单簿事件价格影响](https://arxiv.org/html/1011.6402v3) [EXT123｜Binance Spot WebSocket 原始规范](https://raw.githubusercontent.com/binance/binance-spot-api-docs/master/web-socket-streams.md) [EXT055｜HftBacktest 官方仓库](https://github.com/nkaz001/hftbacktest) [EXT054｜NautilusTrader 官方仓库](https://github.com/nautechsystems/nautilus_trader)

