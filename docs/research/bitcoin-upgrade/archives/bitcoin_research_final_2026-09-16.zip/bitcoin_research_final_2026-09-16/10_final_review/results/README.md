# 实际检查、覆盖与交付边界

本次对上一轮188个包内文件建立目录/身份基线；对当前全部活跃Markdown、JSON、引用和参考SQL做结构检查，对市场方法、提示词、时间/版本、覆盖、权限、报告、任务和迁移进行重点交叉对抗。文件清单见review_inventory.json。不是150个外部网站和67个仓库的逐行源码审计。

## 已运行

- 原创离线文档验证：JSON严格解析、Schema定义、正例及反例、日期format、集合/时点等选定域规则、五种切片依赖、39操作认证声明与本地引用、摘要/文件字节、事实输入保全。
- 参考DDL在新建内存SQLite建表，仅检查参考语法；未连接D1或任何真实数据库。
- 当前Markdown本地链接与显式锚点、JSON/Schema及任务关系扫描。
- 原包归档、逐文件变更清单、当前清单、ZIP完整性。

准确数量以document_checks.json和link_checks.json为准，不将JSON文件解析、路径检查或声明检查称为独立业务用例。原74项与新增收集24项仍是合成验收规格，未在真实业务实现执行。

## 反例来源

baseline_negative_probes.json保留旧契约实际反例：根对象过宽、模式不一致、私有历史审计形状被禁、覆盖状态矛盾。修订后的正反例由tests/validate_document_bundle.py运行；它是有限的可执行设计说明，不是可直接接生产的完整域验证器。

## 未验证

真实仓库/部署、第三方候选运行、全部来源当前可达性/授权、生产数据完整性、模型输出质量、查询吞吐、实际账单与预测价值。旧资料的维护或许可结论按其证据范围使用，本轮外部抽核单独登记。

## 复跑

在已有获准Python与jsonschema环境，手动运行：

```text
python 10_final_review/tests/validate_document_bundle.py --output 10_final_review/results/document_checks.json
```

缺依赖时脚本退出，不自动安装；不发网络请求、不读取账号、不修改业务仓库。Markdown链接扫描属于本轮文档检查，工具脚本另附link_audit.py。归档内历史文件不按当前链接规则强行改写。
