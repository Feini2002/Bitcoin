# 比特币真实仓库深度审查与系统升级包

**交付日期：2026-09-17；固定审查提交：`a6ef6c8974dcdaace32acf25c3a231ecd279ef37`。** 本包直接审阅了当前GitHub关键源码，并修正旧本地报告已过时的能力判断；未执行仓库或候选代码、未连接交易/模型账号、未操作生产D1或部署。

## 最先读什么

[总纲](00_current/00_master_plan.md) → [当前基线](00_current/01_repository_baseline.md) → [30项代码问题与反例](00_current/02_findings_and_counterexamples.md) → 对应四页设计 → [执行任务](00_current/16_work_packages.md)。

**核心决定：保留已有可靠采集、finance数据集与展示底座，先统一数据身份、时间、单位和方法，再增加真正提供独立信息的聚合与分析。** 数据层与情报层并行供给分析，不让五个角色重复总结，也不预设全量迁移Cloudflare。

当前已有32个规范数据集，不能再说FRED/Deribit完全没有；但目录明确未自动采集/未接前端，历史成功记录不证明今天持续在线。标题永续来源已有修复，不重复报告为未修。真正的当前问题包括近端突破逻辑、VWAP近似、POC并列、SFP时点、强平类型/unknown方向、资金费/基差单位、OI窗口与跨页快照方法。

## 正文规模

按汉字逐字计数，本轮当前设计 **59,129** 字；保留且加历史边界的独立研究 **69,347** 字；合计 **128,476** 字。没有用原始仓库输入、旧执行方案、JSON、重复合订本或文件目录凑10万字门槛。保留资料不是本轮全部重新研究，具体日期在每篇内。[计数规则和结果](04_evidence/content_counts.json)。

## 目录与用途

| 路径 | 身份 | 用途 |
|---|---|---|
| `00_current/` | 当前设计，共21卷 | 当前代码审查、四页、方法、三层架构、迁移与任务 |
| `01_execution/` | 当前拟执行 | 48个NEW任务、6类可裁剪切片；不是自动全部执行 |
| `02_contracts/` | 设计/合成 | 小型契约、API职责和一个互相引用的样例链；没有生产迁移SQL |
| `03_validation/` | 拟验收＋本轮文档QA | 66个合成场景，真实仓库执行均未运行 |
| `04_evidence/` | 来源与范围 | 固定提交代码链接、17组外部官方依据、读取限制、字数 |
| `90_reference/` | 2026-09-16历史研究 | 25专题、67复用卡、14案例、收集手册与旧设计底稿 |

## 四个数据页专项

[行情工作台](00_current/05_chart_workbench.md)：确认状态、价格/来源、成交量与quote/base VWAP、结构突破、多周期与历史恢复。

[订单流足迹](00_current/06_orderflow_footprint.md)：分析格/显示格、POC/VA、同价/对角失衡、CVD、SFP可用时点与完整性。

[强平雷达](00_current/07_liquidation_radar.md)：已观测而非全网总额，价格/数量类型、unknown方向、累计更新、窗口与压力条件。

[衍生品](00_current/08_derivatives.md)：费率间隔/状态、OI数量与估值、基差单位、比例语义、期权摘要复用和宏观时间。

补充：[50项方法注册](00_current/09_method_registry.md)、[32数据集接入表](00_current/20_dataset_adoption_cards.md)、[机构公开做法](00_current/03_institutional_patterns.md)、[情报收集](00_current/11_intelligence_collection.md)、[具体提示词与工作流](00_current/12_analysis_prompts_workflow.md)。

## 当前规范与历史资料的优先级

真实较新源码事实优先于本包对旧提交的状态判断；当前NEW任务与00_current的设计优先于90_reference旧WP/SLICE。改变设计仍需记录证据和范围，不因文件较新就自动允许生产操作。历史资料作为选型/方法参考，许可证、版本、数据/API用途采用时逐项重核。

本包没有自动生效AGENTS.md，没有批量安装/抓取脚本，没有授权交易。拟新增路径/接口不冒充现有代码。实际编程前按[Codex接手](00_current/18_codex_handoff.md)绑定当前工作区。

## 已检查与未检查

本轮文档QA见[delivery-summary](03_validation/delivery-summary.json)。检查编码、引用、任务图、Schema正负样例、合成链、文档链接和ZIP，不等于金融方法已在真实代码、模型、浏览器或D1上运行通过。代码级严重反例仍需按66场景接到实际实现。实际数据完整率、费用、效果和生产状态未知。
